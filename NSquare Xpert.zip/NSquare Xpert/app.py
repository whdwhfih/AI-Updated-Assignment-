import os, uuid, fitz, faiss
import numpy as np
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

app = Flask(__name__)
CORS(app)

# Upload folder
os.makedirs("uploads", exist_ok=True)

# Embedding model + FAISS
embedder = SentenceTransformer("all-MiniLM-L6-v2")
dim = embedder.get_sentence_embedding_dimension()
index = faiss.IndexFlatIP(dim)
docs = []

# LLM (Flan-T5)
tok = AutoTokenizer.from_pretrained("google/flan-t5-base")
model = AutoModelForSeq2SeqLM.from_pretrained("google/flan-t5-base")

def chunk_text(text, size=1000, overlap=200):
    """Split text into overlapping chunks"""
    chunks, start = [], 0
    while start < len(text):
        end = min(start + size, len(text))
        chunks.append(text[start:end])
        start += size - overlap
    return chunks

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    file = request.files["file"]
    path = f"uploads/{uuid.uuid4()}.pdf"
    file.save(path)

    # Extract text from PDF
    text = "".join(page.get_text() for page in fitz.open(path))
    chunks = chunk_text(text)

    # Store embeddings
    embs = embedder.encode(chunks, convert_to_numpy=True)
    faiss.normalize_L2(embs)
    index.add(embs)
    docs.extend(chunks)

    return jsonify({"status": "ok", "chunks_added": len(chunks)})

@app.route("/ask", methods=["POST"])
def ask():
    question = request.form["question"]
    top_k = int(request.form.get("top_k", 5))

    # Encode question
    q_emb = embedder.encode([question], convert_to_numpy=True)
    faiss.normalize_L2(q_emb)

    # Search similar chunks
    D, I = index.search(q_emb, top_k)
    ctx = "\n\n".join(docs[i] for i in I[0])

    # Build prompt
    prompt = f"Context:\n{ctx}\n\nQuestion: {question}\nAnswer:"
    inputs = tok(prompt, return_tensors="pt", truncation=True, max_length=1024)
    outputs = model.generate(**inputs, max_length=200)
    ans = tok.decode(outputs[0], skip_special_tokens=True)

    return jsonify({"answer": ans})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=True)
